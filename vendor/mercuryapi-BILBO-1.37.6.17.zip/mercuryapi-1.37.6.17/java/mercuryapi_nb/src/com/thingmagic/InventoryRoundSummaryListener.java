/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.thingmagic;

/**
 * The listener interface for receiving inventory summary report. The class
 * that is interested in processing inventory summary report implements this
 * interface, and the object created with that class is registered
 * with Reader.addInventoryRoundSummaryListener(). When summary report is received,
 * the object's inventorySummary method is invoked.
 */

public interface InventoryRoundSummaryListener 
{
    /**
     * This method is invoked while inventory summary response is embedded in response while streaming
     * @param summary - InventorySummary instance
     */
    void inventorySummary(Reader.InventorySummary summary);
}
